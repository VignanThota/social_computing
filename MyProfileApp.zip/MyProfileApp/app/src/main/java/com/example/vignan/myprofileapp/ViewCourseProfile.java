package com.example.vignan.myprofileapp;
import android.os.AsyncTask;
import android.view.View;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class ViewCourseProfile extends AsyncTask<String, Void, String> {
    @Override
    protected String  doInBackground(String... objects) {
        System.out.print("///////////////////");
        com.example.vignan.myprofileapp.HttpHandler sh = new com.example.vignan.myprofileapp.HttpHandler();
//        HttpHandler sh = new HttpHandler();
        String url = "http://msitis-iiith.appspot.com/api/course/ag5ifm1zaXRpcy1paWl0aHIUCxIHU3R1ZGVudBiAgICA3pCBCww";
        String jsonStr = sh.makeServiceCall(url);
        return jsonStr;

    }
}
