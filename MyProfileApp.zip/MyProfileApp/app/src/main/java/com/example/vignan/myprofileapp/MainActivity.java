package com.example.vignan.myprofileapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {
    String TAG=MainActivity.class.getSimpleName();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String s = "";
        try {
            s = new com.example.vignan.myprofileapp.ViewCourseProfile().execute().get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            //            Log.w(TAG,"except");
            e.printStackTrace();
        }

        String[] data = getDatafromJson(s);
        //        Log.w(TAG,data[0]);
        ArrayAdapter a=new ArrayAdapter(this,R.layout.layout_item_profile,data);
        ListView b=findViewById(R.id.list_view);
        b.setAdapter(a);


    }
    ArrayList<Double> cgpa= new ArrayList<Double>();
    public void calc(String grade,String course)
    {
        if(grade=="Ex")
        {
            cgpa.add(10.0);
            credits(course);
        }
        else if(grade=="A+")
        {
            cgpa.add(9.5);
            credits(course);
        }
        else if(grade=="A")
        {
            cgpa.add(9.0);
            credits(course);
        }
        else if(grade=="B+")
        {
            cgpa.add(8.5);
            credits(course);
        }
        else if(grade=="B")
        {
            cgpa.add(8.0);
            credits(course);
        }
        else if(grade=="C")
        {
            cgpa.add(7.0);
            credits(course);
        }
    }
    ArrayList<Integer> cred = new ArrayList<Integer>();
    public void credits(String id)
    {
        if(id=="IT171111")
        {
            cred.add(1);
        }
        else if(id=="IT171122")
        {
            cred.add(2);
        }
        else if(id=="IT171143")
        {
            cred.add(4);
        }
        else if(id=="IT171147")
        {
            cred.add(4);
        }
        else if(id=="IT171241")
        {
            cred.add(4);
        }
        else if(id=="IT171242")
        {
            cred.add(4);
        }
        else if(id=="IT171321")
        {
            cred.add(2);
        }
        else if(id=="IT171322")
        {
            cred.add(2);
        }
        else if(id=="IT171323")
        {
            cred.add(2);
        }
        else if(id=="IT171441")
        {
            cred.add(4);
        }
        else if(id=="IT171531")
        {
            cred.add(3);
        }
    }
    private String[] getDatafromJson(String s)
    {
        ArrayList<String> st= new ArrayList<String>();
        JSONObject jsonObj;
        try {
            jsonObj  = new JSONObject(s);

            JSONArray contacts = jsonObj.getJSONArray("data");


            for (int i=0;i<contacts.length();i++)
            {  JSONObject c = contacts.getJSONObject(i);
                String course = "Course_id : "+c.getString("course_id");
                String subject  ="Subject : "+c.getString("course_name");
                String grade = "Grade :"+c.getString("grade");
                calc(grade,course);
                String Mentor = "Mentor : "+c.getString("mentor_name");
                st.add(course);
                st.add(subject);
                st.add(grade);
                st.add(Mentor);
            }



        } catch (JSONException e) {
            e.printStackTrace();
        }
        String[] s1 = new String[st.size()];
        s1 =  st.toArray(s1);
        return s1;
    }
    TextView t = findViewById(R.id.tv);
    Doub1[]
}